import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.io.PrintWriter;

@WebServlet("/login")
public class Signin extends HttpServlet {
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws IOException {
        String email = request.getParameter("email");
        String password = request.getParameter("password");

        // In a real application, you should validate the email and password against a database
        // For simplicity, let's assume a hardcoded email and password
        String validEmail = "igirimbabazieric12@gmail.com";
        String validPassword = "123";

        response.setContentType("text/html");
        PrintWriter out = response.getWriter();

        out.println("<!DOCTYPE html>");
        out.println("<html>");
        out.println("<head>");
        out.println("<title>Login Result</title>");
        out.println("</head>");
        out.println("<body>");
        out.println("<h2>Login Result</h2>");

        if (email.equals(validEmail) && password.equals(validPassword)) {
            out.println("<p>Login successful. Welcome, " + email + "!</p>");
            // Redirect to the admission page after a successful login


            response.sendRedirect(request.getContextPath() + "/admission.jsp");
        } else {
            out.println("<p>Invalid email or password. Please try again.</p>");
        }

        out.println("</body>");
        out.println("</html>");
    }
}




