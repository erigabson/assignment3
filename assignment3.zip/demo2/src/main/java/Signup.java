import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.io.PrintWriter;

@WebServlet("/signup")
public class Signup extends HttpServlet {
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws IOException {
        String email = request.getParameter("email");
        String password = request.getParameter("password");

        // Perform signup logic here (validate email, store in database, etc.)
        boolean isSignupSuccessful = performSignup(email, password);

        response.setContentType("text/html");
        PrintWriter out = response.getWriter();

        out.println("<!DOCTYPE html>");
        out.println("<html>");
        out.println("<head>");
        out.println("<title>Signup Result</title>");
        out.println("</head>");
        out.println("<body>");
        out.println("<h2>Signup Result</h2>");

        if (isSignupSuccessful) {
            out.println("<p>Signup successful for email: " + email + "!</p>");
            out.println("<p>Redirecting to Login page...</p>");
            // Redirect to the login page after a successful signup
            response.sendRedirect(request.getContextPath() + "/signin.jsp");
        } else {
            out.println("<p>Signup failed. Please try again.</p>");
        }

        out.println("</body>");
        out.println("</html>");
    }

    private boolean performSignup(String email, String password) {
        // Implement your signup logic here (validate email, store in database, etc.)
        // For simplicity, assume signup is always successful
        return true;
    }
}
