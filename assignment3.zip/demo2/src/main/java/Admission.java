import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.ServletException;
import jakarta.servlet.http.Part;

import java.io.IOException;
import java.io.InputStream;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardCopyOption;

@WebServlet("/admission")
public class Admission extends HttpServlet {

    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws IOException, ServletException {
        Email emails=new Email();
        emails.endemail(request.getParameter("email"));

        // Retrieve form parameters
        String firstName = request.getParameter("firstName");
        String lastName = request.getParameter("lastName");
        String email = request.getParameter("email");
        String dob = request.getParameter("dob");
        String gender = request.getParameter("gender");
        String telephone = request.getParameter("telephone");
        String program = request.getParameter("program");

        // Retrieve uploaded files
        Part passportPicturePart = request.getPart("passportPicture");
        Part diplomaCertificationPart = request.getPart("diplomaCertification");

        // Save uploaded files
        String passportPictureFileName = saveFile(passportPicturePart, "passport_picture");
        String diplomaCertificationFileName = saveFile(diplomaCertificationPart, "diploma_certification");

        // Set attributes to be displayed on the result page
        request.setAttribute("firstName", firstName);
        request.setAttribute("lastName", lastName);
        request.setAttribute("email", email);
        request.setAttribute("dob", dob);
        request.setAttribute("gender", gender);
        request.setAttribute("telephone", telephone);
        request.setAttribute("program", program);
        request.setAttribute("passportPictureFileName", passportPictureFileName);
        request.setAttribute("diplomaCertificationFileName", diplomaCertificationFileName);

        // Forward the request to the result page
        try {
            request.getRequestDispatcher("/admissionresult.jsp").forward(request, response);
        } catch (ServletException e) {
            throw new RuntimeException(e);
        }
    }

    private String saveFile(Part filePart, String fileNamePrefix) throws IOException {
        String fileName = fileNamePrefix + "_" + System.currentTimeMillis() + getFileExtension(filePart);
        String uploadDir = getServletContext().getRealPath("/uploads");

        // Create the upload directory if it doesn't exist
        Path uploadPath = Path.of(uploadDir);
        if (!Files.exists(uploadPath)) {
            Files.createDirectories(uploadPath);
        }

        // Save the file to the server
        try (InputStream fileContent = filePart.getInputStream()) {
            Path filePath = Path.of(uploadDir, fileName);
            Files.copy(fileContent, filePath, StandardCopyOption.REPLACE_EXISTING);
        }

        return fileName;
    }

    private String getFileExtension(Part part) {
        String contentDisposition = part.getHeader("content-disposition");
        String[] tokens = contentDisposition.split(";");
        for (String token : tokens) {
            if (token.trim().startsWith("filename")) {
                String fileName = token.substring(token.indexOf('=') + 1).trim().replace("\"", "");
                return fileName.substring(fileName.lastIndexOf('.') + 1);
            }
        }
        return "";
    }
}
